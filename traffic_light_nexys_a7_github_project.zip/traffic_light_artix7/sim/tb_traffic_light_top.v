`timescale 1ns / 1ps

module tb_traffic_light_top;
    reg clk = 0;
    reg reset = 1;
    wire ns_red, ns_yellow, ns_green;
    wire ew_red, ew_yellow, ew_green;

    // Short timings make the simulation finish quickly.
    traffic_light_top #(
        .CLK_FREQ_HZ(10),
        .GREEN_SEC(2),
        .YELLOW_SEC(1)
    ) dut (
        .clk(clk), .reset(reset),
        .ns_red(ns_red), .ns_yellow(ns_yellow), .ns_green(ns_green),
        .ew_red(ew_red), .ew_yellow(ew_yellow), .ew_green(ew_green)
    );

    always #5 clk = ~clk;

    initial begin
        $dumpfile("traffic_light.vcd");
        $dumpvars(0, tb_traffic_light_top);

        repeat (2) @(posedge clk);
        reset = 0;

        // Check the main sequence and ensure conflicting greens never occur.
        repeat (100) begin
            @(negedge clk);
            if (ns_green && ew_green)
                $fatal(1, "ERROR: both roads are green!");
            if (ns_green && !ew_red)
                $fatal(1, "ERROR: east-west road must be red during north-south green!");
            if (ew_green && !ns_red)
                $fatal(1, "ERROR: north-south road must be red during east-west green!");
        end

        $display("PASS: traffic-light sequence ran without conflicting green signals.");
        $finish;
    end
endmodule
