## Nexys A7 (Artix-7) constraints for Traffic Light Controller
## Board clock: 100 MHz on pin E3.
## Buttons: CPU_RESETN is active-low on C12. The RTL reset is active-high,
## therefore use the onboard reset button through an inverter in RTL or
## change the top-level reset handling as noted below.
##
## LED mapping:
## NS: LD0 (H17), LD1 (K15), LD2 (J13)
## EW: LD3 (N14), LD4 (R18), LD5 (V17)
##
## IMPORTANT: These are Nexys A7 master-XDC package pins. Confirm the exact
## board revision and FPGA part before programming.

set_property -dict { PACKAGE_PIN E3 IOSTANDARD LVCMOS33 } [get_ports clk]
create_clock -add -name sys_clk_pin -period 10.000 -waveform {0 5} [get_ports clk]

## Use a slide switch as active-high reset: SW0 is J15.
set_property -dict { PACKAGE_PIN J15 IOSTANDARD LVCMOS33 } [get_ports reset]

## North-South traffic LEDs
set_property -dict { PACKAGE_PIN H17 IOSTANDARD LVCMOS33 } [get_ports ns_red]
set_property -dict { PACKAGE_PIN K15 IOSTANDARD LVCMOS33 } [get_ports ns_yellow]
set_property -dict { PACKAGE_PIN J13 IOSTANDARD LVCMOS33 } [get_ports ns_green]

## East-West traffic LEDs
set_property -dict { PACKAGE_PIN N14 IOSTANDARD LVCMOS33 } [get_ports ew_red]
set_property -dict { PACKAGE_PIN R18 IOSTANDARD LVCMOS33 } [get_ports ew_yellow]
set_property -dict { PACKAGE_PIN V17 IOSTANDARD LVCMOS33 } [get_ports ew_green]
