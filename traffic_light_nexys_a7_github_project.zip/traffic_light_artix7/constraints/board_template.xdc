## Artix-7 board constraint template
## IMPORTANT:
## 1. Select the exact FPGA part/board in Vivado.
## 2. Replace every <PIN_...> with the correct package pin from your board's
##    official master XDC. Do not guess package pins.
## 3. Confirm the board clock frequency and update CLK_FREQ_HZ if needed.

create_clock -period 10.000 [get_ports clk] ; # 100 MHz example

#set_property PACKAGE_PIN <PIN_CLK> [get_ports clk]
#set_property IOSTANDARD LVCMOS33 [get_ports clk]

#set_property PACKAGE_PIN <PIN_RESET> [get_ports reset]
#set_property IOSTANDARD LVCMOS33 [get_ports reset]

#set_property PACKAGE_PIN <PIN_NS_RED> [get_ports ns_red]
#set_property PACKAGE_PIN <PIN_NS_YELLOW> [get_ports ns_yellow]
#set_property PACKAGE_PIN <PIN_NS_GREEN> [get_ports ns_green]
#set_property PACKAGE_PIN <PIN_EW_RED> [get_ports ew_red]
#set_property PACKAGE_PIN <PIN_EW_YELLOW> [get_ports ew_yellow]
#set_property PACKAGE_PIN <PIN_EW_GREEN> [get_ports ew_green]

#set_property IOSTANDARD LVCMOS33 [get_ports {ns_red ns_yellow ns_green ew_red ew_yellow ew_green}]
