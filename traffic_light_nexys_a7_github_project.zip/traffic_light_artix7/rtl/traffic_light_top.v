`timescale 1ns / 1ps

// Two-road traffic light controller for an Artix-7 FPGA.
// Default timing assumes a 100 MHz board clock.
// Reset is active-high. LED outputs are active-high.
module traffic_light_top #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer GREEN_SEC   = 10,
    parameter integer YELLOW_SEC  = 3
)(
    input  wire clk,
    input  wire reset,
    output reg  ns_red,
    output reg  ns_yellow,
    output reg  ns_green,
    output reg  ew_red,
    output reg  ew_yellow,
    output reg  ew_green
);

    localparam [2:0] NS_GREEN_STATE  = 3'd0,
                     NS_YELLOW_STATE = 3'd1,
                     ALL_RED_1_STATE = 3'd2,
                     EW_GREEN_STATE  = 3'd3,
                     EW_YELLOW_STATE = 3'd4,
                     ALL_RED_2_STATE = 3'd5;

    localparam integer GREEN_TICKS  = CLK_FREQ_HZ * GREEN_SEC;
    localparam integer YELLOW_TICKS = CLK_FREQ_HZ * YELLOW_SEC;
    localparam integer ALL_RED_TICKS = CLK_FREQ_HZ; // 1 second clearance

    reg [2:0] state;
    reg [31:0] timer;
    reg [31:0] state_duration;

    always @* begin
        case (state)
            NS_GREEN_STATE, EW_GREEN_STATE: state_duration = GREEN_TICKS;
            NS_YELLOW_STATE, EW_YELLOW_STATE: state_duration = YELLOW_TICKS;
            ALL_RED_1_STATE, ALL_RED_2_STATE: state_duration = ALL_RED_TICKS;
            default: state_duration = GREEN_TICKS;
        endcase
    end

    always @(posedge clk) begin
        if (reset) begin
            state <= NS_GREEN_STATE;
            timer <= 32'd0;
        end else if (timer >= state_duration - 1) begin
            timer <= 32'd0;
            case (state)
                NS_GREEN_STATE:  state <= NS_YELLOW_STATE;
                NS_YELLOW_STATE: state <= ALL_RED_1_STATE;
                ALL_RED_1_STATE: state <= EW_GREEN_STATE;
                EW_GREEN_STATE:  state <= EW_YELLOW_STATE;
                EW_YELLOW_STATE: state <= ALL_RED_2_STATE;
                ALL_RED_2_STATE: state <= NS_GREEN_STATE;
                default: state <= NS_GREEN_STATE;
            endcase
        end else begin
            timer <= timer + 1'b1;
        end
    end

    always @* begin
        // Safe default: both roads red.
        ns_red = 1'b1; ns_yellow = 1'b0; ns_green = 1'b0;
        ew_red = 1'b1; ew_yellow = 1'b0; ew_green = 1'b0;

        case (state)
            NS_GREEN_STATE: begin
                ns_red = 1'b0; ns_green = 1'b1;
            end
            NS_YELLOW_STATE: begin
                ns_red = 1'b0; ns_yellow = 1'b1;
            end
            EW_GREEN_STATE: begin
                ew_red = 1'b0; ew_green = 1'b1;
            end
            EW_YELLOW_STATE: begin
                ew_red = 1'b0; ew_yellow = 1'b1;
            end
            default: begin
                // Both directions remain red during clearance.
            end
        endcase
    end

endmodule
